const nekopoi = () => { 
	return `       
Mau akses/nonton nekopoi tanpa download vpn? Klik link dibawah ini lalu scroll kebawah terus ketik setuju & hubungkan.

https://www.hidemyass-freeproxy.com/proxy/id-id/aHR0cHM6Ly9uZWtvcG9pLmNhcmUv

*Selamat Menonton*`
}
exports.nekopoi = nekopoi